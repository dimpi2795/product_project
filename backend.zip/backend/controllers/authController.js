// import User from "../models/User.js";
// import bcrypt from 'bcryptjs';


// export const signupUser = async (req, res) => {
//     try{
//         const{ name, email, password } = req.body;

//         // Check if user already exists

//         const userExists = await User.findOne({ email });
       
//         if(userExists){
//             return res.status(400).json({ message: 'User already exists' });
//         }

//         // Hash the password

//         const hashPassword = await bcrypt.hash(password, 10);

//         // Create new user

//         await User.create({
//             name,
//             email,
//             password: hashPassword
//         });

//         res.json({ message: 'User registered successfully' });
 
//     }catch(error){
//         res.status(500).json({ message: 'Server error',error });

//     }
// }


import User from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

export const signupUser = async (req, res) => {
  try {

    const { name, email, password } = req.body;

    // Check empty fields
    if (!name || !email || !password) {
      return res.status(400).json({
        message: "All fields are required",
      });
    }

    // Check if user exists
    const userExists = await User.findOne({ email });

    if (userExists) {
      return res.status(400).json({
        message: "User already exists",
      });
    }

    // Hash password
    const hashPassword = await bcrypt.hash(password, 10);

    // Create user
    await User.create({
      name,
      email,
      password: hashPassword,
    });

    res.status(201).json({
      message: "User registered successfully",
    });

  } catch (error) {

    console.log(error.message);

    res.status(500).json({
      message: "Server error",
    });
  }
};

// Login user
// export const loginUser = async (req, res) => {
//   try{
//     const { email, password } = req.body;

//     const user = await User.findOne({ email });
//     if(!user){
//       return res.status(400).json({
//         message: "User not found",

//       });
//     }

//     //compare password
//     const match =await bcrypt.compare(password,user.password);
//     if(!match){
//       return res.status(400).json({
//         message: "Invalid credentials",
//       });
//     }

//     // Generate JWT token
//     const token =jwt.sign(
    
//        { id: user._id },
//     process.env.JWT_SECRET,
//     { expiresIn: "1d" }
//     );

//     res.json({
//       message: "Login successful",
//       token,
//       user: {
//         id: user._id,
//         name: user.name,
//         email: user.email,
//       },
//     });


//   }catch(error){
//     console.log(error);
//     res.status(500).json({
//       message: "Server error",
//     });
//   }
// }

export const loginUser = async (req, res) => {

  try {

    console.log(req.body);

    const { email, password } = req.body;

    console.log(email, password);

    const user = await User.findOne({ email });

    console.log(user);

    if (!user) {
      return res.status(400).json({
        message: "User not found",
      });
    }

    const match = await bcrypt.compare(
      password,
      user.password
    );

    console.log(match);

    if (!match) {
      return res.status(400).json({
        message: "Invalid credentials",
      });
    }

    console.log(process.env.JWT_SECRET);

    const token = jwt.sign(
      { id: user._id },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    res.json({
      message: "Login successful",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
    });

  } catch (error) {

    console.log(error);

    res.status(500).json({
      message: "Server error",
    });
  }
};