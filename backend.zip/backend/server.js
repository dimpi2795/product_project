// import express from 'express'
// import cors from 'cors'
// import dotenv from 'dotenv';
// import  connectDB  from './config/db.js';
// import authRoutes from './routes/authRoutes.js';
// import productRoutes from './routes/productsRoutes.js';
// import cart from './routes/cart.js';
// import Address from './models/Address.js';
// import addreaaRoutes from "./routes/addressRoutes.js";



// dotenv.config();

// const app = express();

// app.use(cors());
// app.use(express.json());
// app.use('/api/auth', authRoutes);
// app.use('/api/products', productRoutes);
// app.use('/api/cart', cart);
// app.use('/api/address',Address);
// app.use("/address", addressRoutes);


// app.get('/', (req, res) => {
//     res.send('Hello World!');
// })


// connectDB();

// app.listen(process.env.PORT ||8000,()=>{
//     console.log("Server is running on port 8000");
// });


import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import connectDB from "./config/db.js";

import authRoutes from "./routes/authRoutes.js";
import productRoutes from "./routes/productsRoutes.js";
import cartRoutes from "./routes/cart.js";
import addressRoutes from "./routes/address.js";
import orderRoutes from "./routes/order.js";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/cart", cartRoutes);
app.use('/api/address', addressRoutes);  // ← this line missing?
app.use('/api/order',orderRoutes);
app.get("/", (req, res) => {
  res.send("Hello World!");
});

connectDB();

app.listen(process.env.PORT || 8000, () => {
  console.log("Server is running on port 8000");
});